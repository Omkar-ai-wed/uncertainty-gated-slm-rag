"""
run_demo.py
Quickstart demonstration of Uncertainty-Gated Selective Retrieval.
Usage:
    python run_demo.py
"""

import sys
from src.gate import UncertaintyGatedRAG

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

def main():
    print("=" * 75)
    print("DEMO: Uncertainty-Gated Selective Retrieval in Quantized SLMs")
    print("Anonymized Replication Package for Peer Review")
    print("=" * 75)

    model_name = "Qwen/Qwen2.5-0.5B-Instruct"
    pipeline = UncertaintyGatedRAG(model_name=model_name)

    test_queries = [
        ("What is the capital of France?", "Paris is the capital of France.", "Popular Knowledge"),
        ("What was the registration number of the prototype de Havilland Flamingo aircraft?",
         "The prototype de Havilland DH.95 Flamingo first flew with civil registration G-AFPA.", "Long-Tail Knowledge")
    ]

    for q, ctx, desc in test_queries:
        print(f"\n--- Testing [{desc}] ---")
        print(f"Query: {q}")
        res = pipeline.execute_gated_query(q, ctx, tau=2.0, prefix_horizon_m=3)
        print(f"Prefix Predictive Entropy U(q): {res['entropy']:.3f} nats")
        print(f"Routing Decision:              {res['execution_route']}")
        print(f"Generated Output:              {res['generated_answer']}")

    print("\n" + "=" * 75)
    print("Demo execution finished successfully.")

if __name__ == "__main__":
    main()

