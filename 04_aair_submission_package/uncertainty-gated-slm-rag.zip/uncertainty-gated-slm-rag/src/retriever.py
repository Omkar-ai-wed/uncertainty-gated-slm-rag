"""
retriever.py
Knowledge store interface and passage retrieval simulation for selective RAG pipelines.
"""

from typing import Dict, Optional, List


class KnowledgeRetriever:
    """Manages passage lookup and simulated document corpus for benchmark reproduction."""

    def __init__(self, passages_dict: Optional[Dict[str, str]] = None):
        self.passages = passages_dict or {}

    def retrieve(self, query_id: str, query: str, top_k: int = 1) -> List[str]:
        """
        Retrieves passages for a given query identifier or text.
        In benchmark testing, returns exact corpus passages.
        """
        if query_id in self.passages:
            return [self.passages[query_id]]
        # Fallback generic passage
        return [f"General reference document for query: {query}"]
