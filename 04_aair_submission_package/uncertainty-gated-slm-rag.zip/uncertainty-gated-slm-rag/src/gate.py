"""
gate.py
Core algorithm module: Uncertainty-Gated Selective Retrieval for Small Language Models (SLMs).
Evaluates single-pass prefix entropy U(q) and routes queries dynamically.
"""

import math
from typing import Dict, Any, Tuple, Optional
import torch
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModelForCausalLM


class UncertaintyGatedRAG:
    """Manages SLM inference with single-pass predictive entropy gating."""

    def __init__(self, model_name: str, device: str = "cuda" if torch.cuda.is_available() else "cpu",
                 load_in_4bit: bool = False):
        self.device = device
        self.model_name = model_name
        print(f"[*] Initializing model: {model_name} on {device} (4-bit: {load_in_4bit})...")

        self.tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        load_kwargs = {"device_map": "auto" if device == "cuda" else None, "trust_remote_code": True}
        if load_in_4bit and device == "cuda":
            load_kwargs["load_in_4bit"] = True
            load_kwargs["torch_dtype"] = torch.float16
        elif device == "cuda":
            load_kwargs["torch_dtype"] = torch.float16

        self.model = AutoModelForCausalLM.from_pretrained(model_name, **load_kwargs)
        if device == "cpu":
            self.model.to("cpu")
        self.model.eval()

    def compute_prefix_entropy(self, query: str, prefix_horizon_m: int = 3) -> float:
        """
        Calculates average predictive Shannon entropy over the first M decoded tokens:
        U(q) = - 1/M * sum_{m=1}^M sum_{v in V} P(y_m=v | q, y_<m) log P(y_m=v | q, y_<m)
        """
        prompt = f"Question: {query}\nAnswer with a concise, direct factual answer:\nAnswer:"
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)

        entropies = []
        input_ids = inputs["input_ids"]

        with torch.no_grad():
            for step in range(prefix_horizon_m):
                outputs = self.model(input_ids=input_ids)
                next_token_logits = outputs.logits[:, -1, :]  # Shape: (1, vocab_size)

                # Softmax probabilities over entire vocabulary
                probs = F.softmax(next_token_logits, dim=-1)
                log_probs = F.log_softmax(next_token_logits, dim=-1)

                # Shannon entropy in natural units (nats): H = - sum(p * log(p))
                entropy = -torch.sum(probs * log_probs, dim=-1).item()
                entropies.append(entropy)

                # Greedy step to predict prefix token
                next_token_id = torch.argmax(probs, dim=-1).unsqueeze(-1)
                input_ids = torch.cat([input_ids, next_token_id], dim=-1)

        return float(sum(entropies) / len(entropies))

    def generate_parametric(self, query: str, max_new_tokens: int = 16) -> str:
        """Generates answer strictly using internal parametric weights (Closed-Book)."""
        prompt = f"Question: {query}\nAnswer with a concise, direct factual answer:\nAnswer:"
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)

        with torch.no_grad():
            output_ids = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=False,  # Deterministic greedy decoding
                pad_token_id=self.tokenizer.pad_token_id
            )

        new_tokens = output_ids[0][inputs["input_ids"].shape[1]:]
        return self.tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

    def generate_rag(self, query: str, context: str, max_new_tokens: int = 16) -> str:
        """Generates answer conditioned on retrieved external passage (Augmented)."""
        prompt = (
            f"Context: {context}\n\n"
            f"Based strictly on the context above, answer the following question concisely.\n"
            f"Question: {query}\n"
            f"Answer:"
        )
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)

        with torch.no_grad():
            output_ids = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=False,
                pad_token_id=self.tokenizer.pad_token_id
            )

        new_tokens = output_ids[0][inputs["input_ids"].shape[1]:]
        return self.tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

    def execute_gated_query(self, query: str, context_candidate: str,
                            tau: float = 2.0, prefix_horizon_m: int = 3) -> Dict[str, Any]:
        """
        Executes Uncertainty-Gated Selective Retrieval:
        1. Measure predictive prefix entropy U(q).
        2. If U(q) < tau: Bypass RAG -> Parametric generation.
        3. If U(q) >= tau: Trigger RAG -> Augmented generation with context.
        """
        entropy = self.compute_prefix_entropy(query, prefix_horizon_m)
        bypass_retrieval = (entropy < tau)

        if bypass_retrieval:
            answer = self.generate_parametric(query)
            route = "PARAMETRIC_BYPASS"
        else:
            answer = self.generate_rag(query, context_candidate)
            route = "RETRIEVAL_AUGMENTED"

        return {
            "query": query,
            "entropy": round(entropy, 4),
            "threshold": tau,
            "bypass_retrieval": bypass_retrieval,
            "execution_route": route,
            "generated_answer": answer
        }

