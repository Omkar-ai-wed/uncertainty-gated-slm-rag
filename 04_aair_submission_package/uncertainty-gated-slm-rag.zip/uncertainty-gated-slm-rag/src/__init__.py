"""
Uncertainty-Gated Selective Retrieval in Small Language Models (SLMs)
Package Initialization (Anonymized for Double-Blind Peer Review)
"""

from .gate import UncertaintyGatedRAG
from .telemetry import HardwareTelemetry
from .retriever import KnowledgeRetriever

__all__ = ["UncertaintyGatedRAG", "HardwareTelemetry", "KnowledgeRetriever"]

