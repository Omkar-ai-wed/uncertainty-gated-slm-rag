"""
run_benchmark.py
Reproduces the Factual Knowledge Entropy Separation and Selective Gating Benchmarks (Tables 4, 5, 8).
Usage:
    python scripts/run_benchmark.py --model "Qwen/Qwen2.5-0.5B-Instruct" --tau 2.0 --m 3
"""

import os
import sys
import json
import argparse
import numpy as np
from tabulate import tabulate

# Add src to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.gate import UncertaintyGatedRAG
from src.telemetry import HardwareTelemetry

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')


def parse_args():
    parser = argparse.ArgumentParser(description="Evaluate Uncertainty-Gated RAG across Factual Benchmarks.")
    parser.add_argument("--model", type=str, default="Qwen/Qwen2.5-0.5B-Instruct",
                        help="HuggingFace model identifier (e.g. Qwen/Qwen2.5-0.5B-Instruct, meta-llama/Llama-3.2-1B-Instruct).")
    parser.add_argument("--tau", type=float, default=2.0,
                        help="Epistemic decision threshold tau in nats (default: 2.0).")
    parser.add_argument("--m", type=int, default=3,
                        help="Prefix decoding horizon M in tokens (default: 3).")
    parser.add_argument("--load_in_4bit", action="store_true",
                        help="Load model in 4-bit quantization (AWQ/BitsAndBytes).")
    parser.add_argument("--data_path", type=str,
                        default=os.path.join(os.path.dirname(__file__), "..", "data", "benchmark_queries.json"),
                        help="Path to benchmark JSON queries.")
    return parser.parse_args()


def main():
    args = parse_args()

    print("=" * 80)
    print("UNCERTAINTY-GATED SELECTIVE RETRIEVAL BENCHMARK")
    print(f"Model: {args.model} | Decision Threshold tau: {args.tau} nats | Prefix Horizon M: {args.m}")
    print("=" * 80)

    # Load dataset
    with open(args.data_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    queries = data["queries"]

    # Initialize RAG Pipeline and Telemetry
    pipeline = UncertaintyGatedRAG(model_name=args.model, load_in_4bit=args.load_in_4bit)
    telemetry = HardwareTelemetry()

    results = []
    pop_entropies = []
    tail_entropies = []
    bypassed_count = 0

    print(f"\n[*] Evaluating {len(queries)} benchmark queries...")

    for item in queries:
        q_id = item["id"]
        q_type = item["type"]
        query = item["query"]
        gold = item["gold"]
        passage = item["passage"]

        telemetry.start()
        gated_res = pipeline.execute_gated_query(query, passage, tau=args.tau, prefix_horizon_m=args.m)
        perf = telemetry.stop()

        entropy = gated_res["entropy"]
        route = gated_res["execution_route"]
        pred = gated_res["generated_answer"]
        is_bypass = gated_res["bypass_retrieval"]

        if q_type == "popular":
            pop_entropies.append(entropy)
            if is_bypass:
                bypassed_count += 1
        else:
            tail_entropies.append(entropy)

        # Factual hit: check if gold string appears in output
        hit = gold.lower() in pred.lower()

        results.append([
            q_id, q_type, f"{entropy:.3f}", route,
            pred[:35] + ("..." if len(pred) > 35 else ""),
            "HIT" if hit else "MISS",
            f"{perf['latency_ms']:.1f} ms"
        ])

    # Print summary table
    headers = ["ID", "Category", "Entropy (nats)", "Route", "Generated Output", "Factual Match", "Latency"]
    print("\n" + tabulate(results, headers=headers, tablefmt="github"))

    # Statistical Analysis
    mean_pop = float(np.mean(pop_entropies)) if pop_entropies else 0.0
    mean_tail = float(np.mean(tail_entropies)) if tail_entropies else 0.0
    std_pop = float(np.std(pop_entropies)) if pop_entropies else 0.0
    std_tail = float(np.std(tail_entropies)) if tail_entropies else 0.0
    delta_u = mean_tail - mean_pop

    pop_total = len(pop_entropies)
    bypass_rate = (bypassed_count / pop_total) * 100.0 if pop_total > 0 else 0.0

    print("\n" + "=" * 80)
    print("EMPIRICAL STATISTICAL SUMMARY")
    print(f"Mean Popular Entity Entropy (mu_pop):  {mean_pop:.3f} +- {std_pop:.3f} nats")
    print(f"Mean Long-Tail Entity Entropy (mu_tail): {mean_tail:.3f} +- {std_tail:.3f} nats")
    print(f"Empirical Entropy Gap (Delta U):       {delta_u:.3f} nats")
    print(f"Retrieval Bypass Rate (Popular):        {bypass_rate:.1f}%")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()
