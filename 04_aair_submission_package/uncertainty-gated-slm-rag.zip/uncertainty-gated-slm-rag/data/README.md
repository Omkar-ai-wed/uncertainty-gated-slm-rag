# Benchmark Datasets

This repository includes a 20-query calibrated pilot evaluation suite in `benchmark_queries.json` comprising 10 high-popularity entity queries (PopQA subset) and 10 long-tail entity queries.

## Full Evaluation Benchmarks

To reproduce the full paper results across all 18,694 queries reported in the manuscript:

### 1. PopQA (14,267 queries)
- **Source:** [Mallen et al., 2023](https://github.com/Alex-Mallen/PopQA)
- **Evaluation:** Evaluates accuracy across entity monthly Wikipedia pageviews from $10^2$ to $10^8$.
- **Download:**
  ```bash
  wget https://raw.githubusercontent.com/Alex-Mallen/PopQA/main/data/popQA.tsv
  ```

### 2. Natural Questions Open (NQ-Open, 3,610 queries)
- **Source:** [Kwiatkowski et al., 2019; Lee et al., 2019](https://github.com/google-research-datasets/natural-questions)
- **Evaluation:** Real-world informational queries extracted from Google search logs.

### 3. TruthfulQA (817 queries)
- **Source:** [Lin et al., 2022](https://github.com/sylinrl/TruthfulQA)
- **Evaluation:** Assesses susceptibility to popular misconceptions, cognitive biases, and false superstitious rationalizations.
