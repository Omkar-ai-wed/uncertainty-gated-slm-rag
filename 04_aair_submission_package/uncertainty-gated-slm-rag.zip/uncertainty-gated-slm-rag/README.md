# Uncertainty-Gated Selective Retrieval in Quantized Small Language Models

> **Official Replication Repository**  
> Anonymized for Double-Blind Peer Review  
> Accompanying manuscript submitted to *Advances in Artificial Intelligence Research* (AAIR)

[![License: Apache-2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-green.svg)](https://www.python.org/)
[![PyTorch 2.1+](https://img.shields.io/badge/PyTorch-2.1+-ee4c2c.svg)](https://pytorch.org/)
[![HuggingFace Transformers](https://img.shields.io/badge/%F0%9F%A4%97-Transformers-yellow)](https://huggingface.co/)

---

## 1. Overview

Retrieval-Augmented Generation (RAG) is established as an effective mechanism to reduce factual errors in large language models. However, standard architectures unconditionally retrieve external passages for all queries. When deployed with resource-constrained **Small Language Models (SLMs, 0.5B–8B parameters)** on edge hardware, this always-on paradigm introduces two severe vulnerabilities:

1. **Context Distraction & Hallucination Amplification:** Due to constrained parameter capacity, compact decoders are easily misled when dense retrievers return irrelevant, conflicting, or adversarial distractors, causing hallucinations on facts the model already encodes internally.
2. **Inference & Energy Inefficiency:** Static retrieval incurs substantial vector search latency and increases prompt token length, wasting compute and electrical power on common-knowledge queries.

This repository provides the reference implementation of **Uncertainty-Gated Selective Retrieval**, a lightweight, training-free routing framework that evaluates a single-pass predictive Shannon entropy probe $\mathcal{U}(q)$ over an initial prefix decoding horizon ($M = 3$ tokens). 

* **If $\mathcal{U}(q) < \tau$ (High Parametric Confidence):** The query is answered directly from the SLM's internal weights, bypassing retrieval entirely.
* **If $\mathcal{U}(q) \ge \tau$ (Epistemic Uncertainty):** External retrieval is triggered to augment the prompt with relevant corpus evidence.

```
Incoming Query (q) ───► Single-Pass Prefix Probe (M=3) ───► Compute U(q)
                                                                 │
                                ┌────────────────────────────────┴──────────────────────────────┐
                                ▼                                                               ▼
                     U(q) < tau (Confident)                                          U(q) >= tau (Uncertain)
                                │                                                               │
                                ▼                                                               ▼
                     PARAMETRIC BYPASS                                                RETRIEVAL TRIGGERED
                     Direct SLM Inference                                             Dense Vector Retrieval
                     (0ms Retrieval Overhead)                                         Context-Grounded Inference
```

---

## 2. Mathematical Formulation

For an input query $q$ and Small Language Model with parameters $\theta$, the predictive Shannon entropy across a prefix horizon of $M$ tokens is computed as:

$$\mathcal{U}(q) = -\frac{1}{M} \sum_{m=1}^M \sum_{v \in \mathcal{V}} P_\theta(y_m = v \mid q, y_{<m}) \log P_\theta(y_m = v \mid q, y_{<m})$$

where $\mathcal{V}$ denotes the vocabulary. With an empirical decision threshold $\tau = 2.0\text{ nats}$ and horizon $M = 3$:
* Queries with high parametric confidence exhibit sharply peaked token distributions ($\mathcal{U}(q) < \tau$), safely bypassing retrieval.
* Queries involving long-tail, obscure, or time-sensitive entities produce diffuse logits ($\mathcal{U}(q) \ge \tau$), routing the query to dense retrieval.

---

## 3. Repository Structure

```text
uncertainty-gated-slm-rag/
├── README.md                  # Anonymous overview, formulation, and execution guide
├── requirements.txt           # Minimal pinned Python dependencies
├── LICENSE                    # Apache 2.0 License (Anonymized)
├── .gitignore                 # Standard Python gitignore
├── run_demo.py                # Standalone 1-click quickstart verification
├── src/                       # Core algorithm modules
│   ├── __init__.py
│   ├── gate.py                # Predictive entropy computation & gating logic
│   ├── retriever.py           # Passage retrieval and knowledge store interface
│   └── telemetry.py           # Hardware latency, VRAM, and NVML energy tracker
├── scripts/                   # Empirical reproduction scripts
│   ├── run_benchmark.py       # Reproduces Tables 4, 5, 8 (PopQA / NQ / TruthfulQA)
│   └── run_noise_test.py      # Reproduces Table 6 (Context distraction study)
└── data/                      # Benchmark evaluation suite
    ├── benchmark_queries.json # 20-query calibrated evaluation suite
    └── README.md              # Instructions for full benchmark evaluation
```

---

## 4. Installation & Setup

### Prerequisites
* Python 3.10 or higher
* CUDA-compatible GPU (recommended for 4-bit quantized deployment) or CPU

### Environment Setup
```bash
# Clone the anonymized repository
git clone https://github.com/[anonymized]/uncertainty-gated-slm-rag.git
cd uncertainty-gated-slm-rag

# Create and activate a clean virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt
```

---

## 5. Quickstart Demonstration

Run the quickstart script to verify the entropy gate on representative popular and long-tail questions:

```bash
python run_demo.py
```

Expected output:
```text
--- Testing [Popular Knowledge] ---
Query: What is the capital of France?
Prefix Predictive Entropy U(q): 0.612 nats
Routing Decision:              PARAMETRIC_BYPASS
Generated Output:              Paris

--- Testing [Long-Tail Knowledge] ---
Query: What was the registration number of the prototype de Havilland Flamingo aircraft?
Prefix Predictive Entropy U(q): 2.845 nats
Routing Decision:              RETRIEVAL_AUGMENTED
Generated Output:              G-AFPA
```

---

## 6. Reproducing Paper Benchmarks

### Experiment 1: Factual Knowledge Entropy Separation (Tables 4, 5, & 8)
Evaluates predictive entropy separation between popular parametric entities and long-tail entities:

```bash
python scripts/run_benchmark.py --model "Qwen/Qwen2.5-0.5B-Instruct" --tau 2.0 --m 3
```

To evaluate 4-bit quantized models:
```bash
python scripts/run_benchmark.py --model "Qwen/Qwen2.5-1.5B-Instruct" --tau 2.0 --m 3 --load_in_4bit
```

### Experiment 2: Adversarial Noise Distraction & Stress Testing (Table 6)
Demonstrates that unconditional static RAG causes SLM hallucinations when presented with distracting or contradictory passages, whereas Uncertainty Gating preserves parametric accuracy:

```bash
python scripts/run_noise_test.py --model "Qwen/Qwen2.5-0.5B-Instruct" --tau 2.0
```

---

## 7. Key Empirical Findings Reported in Manuscript

| Evaluation Metric | Baseline Static RAG | Uncertainty-Gated RAG (Ours) | Delta / Improvement |
| :--- | :---: | :---: | :---: |
| **Popular Entity Bypass Rate** | 0.0% (Always retrieves) | **74.8%** | **+74.8% bypass** |
| **Mean End-to-End Latency** | 246.8 ms | **152.1 ms** | **-38.4% faster** |
| **GPU Energy Consumption** | 3.82 Joules / query | **2.60 Joules / query** | **-31.9% energy cut** |
| **Hallucination Error Rate (50% Distractors)** | 44.8% | **28.2%** | **-16.6% error reduction** |
| **Fine-Tuning / Retraining Required** | None | **None (Zero fine-tuning)** | **100% Post-hoc** |

---

## 8. Anonymized Citation

```bibtex
@article{anonymized2026uncertainty,
  title     = {Uncertainty-Gated Selective Retrieval in Quantized Small Language Models: Mitigating Noise-Induced Hallucination and Latency in Edge Deployment},
  author    = {Anonymous Authors},
  journal   = {Advances in Artificial Intelligence Research},
  year      = {2026},
  note      = {Under double-blind peer review}
}
```

---

## 9. License

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

